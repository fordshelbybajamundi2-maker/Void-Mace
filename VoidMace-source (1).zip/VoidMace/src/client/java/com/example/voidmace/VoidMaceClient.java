package com.example.voidmace;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;

public final class VoidMaceClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        EntityRendererRegistry.register(VoidMaceMod.VOID_MACE_PROJECTILE, FlyingItemEntityRenderer::new);
    }
}
