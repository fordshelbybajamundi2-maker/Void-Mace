# Void Mace (Fabric 1.21.1)

A starter Fabric mod project for Minecraft Java Edition 1.21.1. Right-click with the Void Mace to throw it. The projectile records the most recent non-owner player it hits, teleports that player to its block-impact location when it lands, and returns the mace to the owner's inventory (dropping it if the inventory is full).

## Requirements
- Java JDK 21
- Minecraft Java Edition 1.21.1
- Fabric Loader compatible with 1.21.1
- Fabric API for 1.21.1
- Internet access for the first Gradle build so Gradle can download Minecraft/Fabric dependencies

## Build
From this folder, run:

- Windows: `gradle build` (or use a Gradle wrapper if you add one)
- macOS/Linux: `gradle build`

The remapped mod jar should appear under `build/libs/` with a name like `voidmace-1.0.0.jar`.

## Install
1. Install Fabric Loader for Minecraft 1.21.1.
2. Install the matching Fabric API into `.minecraft/mods`.
3. Copy `voidmace-1.0.0.jar` from `build/libs/` into `.minecraft/mods`.
4. Start the Fabric 1.21.1 profile.
5. In a world with cheats enabled, use `/give @p voidmace:void_mace` to obtain it.

## Notes
- This project targets Minecraft **1.21.1**, the specific 1.21.x patch selected for this build.
- The item currently uses the vanilla mace texture as a placeholder; custom purple/void art can be added later.
- This environment did not have Gradle installed and could not access external download hosts, so the `.jar` could not be compiled here. Build the source project on a computer with Gradle and internet access.
